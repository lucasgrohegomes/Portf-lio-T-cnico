function mudarcordessamerda(id){
if (id == "vermelho") {
document.body.style.background = "darkorange"
}
else if(id == "azul"){ 
document.body.style.background = "lightblue"
}
else if(id == "ruan"){  
document.body.style.background = "plum"
}
        
}
